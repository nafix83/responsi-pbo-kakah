/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOInterfaceBuku;
import model.ModelDataBuku;
import java.util.List;
/**
 *
 * @author Lab Informatika
 */
public interface DAOimplBuku {
    public void insert(ModelDataBuku b);
    public void delete(ModelDataBuku b);
    public void update(ModelDataBuku b);
    public List<ModelDataBuku> getAll();
}
