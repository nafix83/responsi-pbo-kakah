/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.lang.reflect.Array;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Lab Informatika
 */
public class ModelDataTabel extends AbstractTableModel{

    private ArrayList<ModelDataBuku> listbuku;
    
    public ModelDataTabel (ArrayList<ModelDataBuku> listbuku) {
        this.listbuku = listbuku;
    }
    @Override
    public int getRowCount() {
        return listbuku.size();
    }

    @Override
    public int getColumnCount() {
    return 4;
    }

    public String getColumnName(int column){
    switch(column){
            case 0 :
                return "judul";
            case 1:
                return "alur";
            case 2:
                return "orisinalitas";
            case 3:
                return "pemilihan kata";
            default:
                return null;
            
               }
        
    }
    
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return.listbuku.get(rowIndex).getJudul();
            case 1:
                return.listbuku.get(rowIndex).getAlur();
            case 2:
                return.listbuku.get(rowIndex).getOri()
           
            case 3 :
                return.listbuku.get(rowIndex).getOri();
                
             default:return null;
        
        }
        
    }
    
}
