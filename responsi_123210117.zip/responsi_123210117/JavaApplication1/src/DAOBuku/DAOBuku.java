/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOBuku;

import java.util.List;
import model.ModelDataBuku;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import koneksi.Koneksi;

/**
 *
 * @author Lab Informatika
 */
public class DAOBuku implements DAOInterfaceBuku.DAOimplBuku {
    
    Connection con = koneksi.Koneksi.connection();
    private String judul;

    @Override
    public void insert(ModelDataBuku b) {
       String sql = "INSERT INTO lomba (judul,alur,ori,kata,nilai) Value (?,?,?,?,?)";  
        try{
                
           PreparedStatement ps = con.prepareStatement(sql);
           ps.setString(1, b.getJudul());
           ps.setString(2, b.getAlur());
           ps.setString(3, b.getOri());
           ps.setString(4, b.getKata());
           ps.setDouble(5, b.getNilai());
       }catch (SQLException ex){
               ex.printStackTrace();
           }
           
       
       
    }

    @Override
    public void delete(ModelDataBuku b) {
      String sql = "DELATE FROM lomba where judul=?;";
        try{
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, judul);
            ps.executeUpdate();            
      }catch(SQLException ex){
          ex.printStackTrace();
      }
    }

    @Override
    public void update(ModelDataBuku b) {
        String sql = "UPDATE lomba SET judul=?,alur=?,ori=?,kata=?,nilai,=?;";
        try{
          PreparedStatement ps = con.prepareStatement(sql);
          ps.setString(1, b.getJudul());
           ps.setString(2, b.getAlur());
           ps.setString(3, b.getOri());
           ps.setString(4, b.getKata());
           ps.setDouble(5, b.getNilai());
            System.out.println("DAOBuku.DAOBuku.update()");
           ps.executeUpdate();    
        
        } catch (SQLException ex) {
            Logger.getLogger(DAOBuku.class.getName()).log(Level.SEVERE, null, ex);
        }
   }

    @Override
    public List<ModelDataBuku> getAll() {
        List<ModelDataBuku> list = new ArrayList<>();
        String sql ="SELECT * FOR< lomba ; ";
       
        try{
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        
            while(rs.next){
                ModelDataBuku p = new ModelDataBuku();
                p.setJudul(rs.getString("judul"));
                p.setAlur(rs.getString("alur"));
                p.setOri(rs.getString("orisinalitas"));
                p.setKata(rs.getString("pemilihankata"));
                p.setNilai(rs.getDouble("nilai"));
            
            
            }
        
        
        }catch(SQLException ex){
        ex.printStackTrace();
        }
        
        
        
        
        return list;
        
    
    }

   
}
