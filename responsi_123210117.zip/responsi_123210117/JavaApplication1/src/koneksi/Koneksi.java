/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;
import java.sql.Connection;
import java.sql.SQLException;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.swing.JOptionPane;
/**
 *
 * @author Lab Informatika
 */
public class Koneksi {
       static Connection con;
        public static Connection connection() {
            if(con==null){
                MysqlDataSource data =new MysqlDataSource();
                data.setDatabaseName("responsi");
                data.setUser("root");
                data.setPassword("");
                try{
                    con = data.getConnection();
                    System.out.println("koneksi.Koneksi.connection()");
                    
                }catch(SQLException ex){
                            
                            
                            Logger.getLogger(Koneksi.class.getName()).log(Level.SEVERE,null,ex);
                    
                }
            
            
            }


return con;
}
    
}
